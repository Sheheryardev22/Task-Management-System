<!doctype html>
<html>
    <head>
        <title>TMS</title>
        <!--jquery-->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        
        <!--bootstrap-->
        
        <link rel="stylesheet" type="text/css" href="bootstrap-5.3.2-dist/css/bootstrap.min.css">
    <!-- linking the style sheet-->
        <link rel="stylesheet" type="text/css" href="styles.css">
        
    </head>
    <body>
        <center><h3 style="background-color: #BF3131; height:60px;text-align:center;color:#F3EDC8;">Choose Your Role</h3>
                </center><br>
         <center>
                <a href="user_login.php" class="btn btn-success" style="background-color:#BF3131;">User Login</a><br><br>
                <a href="register.php" class="btn btn-success" style="background-color:#BF3131;">User Registration</a><br><br>
                <a href="admin_login.php" class="btn btn-success" style="background-color:#BF3131;">
                Admin Login</a><br><br>
            
            </center>
    </body>
</html>